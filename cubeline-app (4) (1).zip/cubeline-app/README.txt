CUBELINE - all-in-one Minecraft launcher

Run it:       double-click Start-Cubeline.bat   (first run installs what it needs)
Make an .exe: double-click Build-EXE.bat         (creates dist\Cubeline.exe, a single file you can keep and share)
Mac/Linux:    npm install, then npm start

Needs Node.js (nodejs.org) once. Playing needs a Microsoft account that owns Minecraft: Java Edition,
and a recent Java (probably Java 25). If the game closes right away, put the java path in Settings.
