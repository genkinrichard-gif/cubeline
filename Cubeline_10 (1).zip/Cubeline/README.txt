CUBELINE - all-in-one Minecraft launcher

Run it:       double-click Start-Cubeline.bat   (first run installs what it needs)
Make an .exe: double-click Build-EXE.bat         (creates dist\Cubeline.exe, a single file you can keep and share)
Mac/Linux:    npm install, then npm start

Needs Node.js (nodejs.org) once. In Settings > Play mode you can choose:
  - Microsoft account (online): needs an account that owns Minecraft: Java Edition
  - Offline (default): no login or account needed, uses the name you picked (online servers will not accept it)
Java: you do NOT need to install it. Cubeline downloads the right Java for each Minecraft version from Mojang
(first Play of a version only). If you want your own Java, put its path in Settings.

SKIN IN THE GAME
  The skin you pick in Cubeline now shows up inside Minecraft too (64x64 or 64x32 PNG).
  - Offline: Cubeline runs a tiny local skin server while the game is open and loads a small helper
    (authlib-injector, downloaded once on first Play with a skin). Needs internet that first time.
  - Microsoft account: the skin is uploaded to your account (same as changing it on minecraft.net).
  Slim (Alex-style) arms are detected automatically. Other players on servers will NOT see an offline skin.

MODS, SHADERS AND RESOURCE PACKS (Mods button)
  Tabs: All, Mods, Shaders, Resource packs. Each tab has Installed and Browse library
  (except All), on/off switches and Remove. Items come from Modrinth.
  Mods need Fabric; Cubeline switches the loader to Fabric when you add a mod.
  Shaders need Iris. Cubeline installs Iris automatically on Play. Only the first enabled shader is used.
  Resource packs are loaded when you press Play.
