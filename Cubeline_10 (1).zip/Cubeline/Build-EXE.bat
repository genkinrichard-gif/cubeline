@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Install Node.js first: https://nodejs.org & pause & exit /b)
call npm install
call npm run build
echo.
echo Done. Your single Cubeline.exe is in the "dist" folder.
pause
