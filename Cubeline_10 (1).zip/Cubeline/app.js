// Cubeline: all-in-one Minecraft launcher (UI + launcher logic in this single file)
// The UI is stored in HTML below as one string. Edit it, or rebuild it from a normal .html file.
const HTML = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>Cubeline</title>\n<style>\n:root{\n  --sky:#14103a; --plum:#4a2a7a; --glow:#ff8a8a; --grass:#5fa83a; --grass-d:#3d7a22; --grass-l:#8fd45c;\n  --dirt:#7a5230; --stone:#8b8b8b; --ink:#0d0a24; --text:#f6f0e4;\n  --mono:\"Lucida Console\",\"Cascadia Mono\",Consolas,\"Courier New\",monospace;\n}\n*{box-sizing:border-box;margin:0}\nhtml,body{height:100%;overflow:hidden;background:var(--sky);color:var(--text);font-family:var(--mono)}\n#bg{position:fixed;inset:0;width:100%;height:100%;image-rendering:pixelated}\nmain{position:relative;height:100%;display:flex;flex-direction:column;justify-content:space-between;padding:clamp(20px,4vw,48px)}\nh1{font-size:clamp(40px,7vw,76px);letter-spacing:-.02em;line-height:1;text-shadow:5px 5px 0 var(--ink)}\n.brand p{margin-top:10px;font-size:14px;text-shadow:2px 2px 0 var(--ink);opacity:.9}\n.dock{align-self:center;text-align:center;width:min(380px,100%);padding:20px;background:rgba(13,10,36,.78);\n  border:4px solid var(--ink);box-shadow:inset 0 0 0 3px #3b3470,8px 8px 0 rgba(0,0,0,.45);display:grid;gap:12px}\n.who{font-size:13px;display:flex;align-items:center;gap:10px}\n.who i{width:16px;height:16px;background:var(--stone);box-shadow:inset -3px -3px 0 #5b5b5b,inset 3px 3px 0 #bdbdbd}\n.who.on i{background:var(--grass);box-shadow:inset -3px -3px 0 var(--grass-d),inset 3px 3px 0 var(--grass-l)}\n.ver{font-size:13px;opacity:.85}\nbutton{font:inherit;color:var(--text);cursor:pointer}\nbutton:focus-visible,select:focus-visible,input:focus-visible{outline:3px solid #ffe27a;outline-offset:2px}\n.play{padding:18px;font-size:30px;font-weight:700;letter-spacing:.04em;text-shadow:3px 3px 0 #1c3a0e;\n  background:var(--grass);border:4px solid #1c3a0e;\n  box-shadow:inset 0 -8px 0 var(--grass-d),inset 0 5px 0 var(--grass-l),0 6px 0 #1c3a0e;transition:transform .08s,box-shadow .08s,filter .15s}\n.play:hover{filter:brightness(1.1)}\n.play:active{transform:translateY(5px);box-shadow:inset 0 -8px 0 var(--grass-d),inset 0 5px 0 var(--grass-l),0 1px 0 #1c3a0e}\n.play:disabled{filter:grayscale(.7) brightness(.8);cursor:progress}\n.ghost{padding:12px;font-size:16px;font-weight:700;background:#6e6e78;border:4px solid var(--ink);\n  box-shadow:inset 0 -5px 0 #4a4a54,inset 0 3px 0 #a3a3ae;text-shadow:2px 2px 0 var(--ink)}\n.ghost:hover{background:#7d7d89}\n.bar{height:16px;background:var(--ink);border:3px solid #3b3470}\n.bar i{display:block;height:100%;width:0;background:repeating-linear-gradient(90deg,var(--grass) 0 12px,var(--grass-d) 12px 16px);transition:width .2s}\n#status{font-size:12px;min-height:16px;opacity:.9}\n#status.err{color:#ffb4b4;opacity:1}\ndialog{margin:auto;width:min(440px,92vw);padding:24px;background:#1d1848;color:var(--text);border:4px solid var(--ink);\n  box-shadow:inset 0 0 0 3px #4b4392,10px 10px 0 rgba(0,0,0,.5);font-family:var(--mono)}\ndialog::backdrop{background:rgba(8,6,24,.6)}\ndialog[open]{animation:pop .14s steps(3)}\n@keyframes pop{from{transform:scale(.92);opacity:.4}to{transform:none;opacity:1}}\ndialog h2{font-size:24px;text-shadow:3px 3px 0 var(--ink);margin-bottom:16px}\nlabel{display:block;font-size:13px;margin:14px 0 6px}\nselect,input[type=text]{width:100%;padding:10px;font:inherit;font-size:14px;color:var(--text);background:var(--ink);border:3px solid #4b4392}\ninput[type=range]{width:100%;accent-color:var(--grass)}\n.row{display:flex;align-items:center;gap:8px;font-size:13px;margin-top:10px}\n.acct{display:flex;justify-content:space-between;align-items:center;margin-top:18px;padding-top:14px;border-top:3px solid #3b3470;font-size:13px;gap:10px}\n.mini{padding:8px 12px;font-size:13px;background:#6e6e78;border:3px solid var(--ink);box-shadow:inset 0 -3px 0 #4a4a54}\n.actions{display:flex;gap:10px;margin-top:22px}\n.actions button{flex:1;padding:12px;font-size:15px;font-weight:700;border:4px solid var(--ink)}\n.save{background:var(--grass);box-shadow:inset 0 -5px 0 var(--grass-d),inset 0 3px 0 var(--grass-l);text-shadow:2px 2px 0 #1c3a0e}\n.close{background:#6e6e78;box-shadow:inset 0 -5px 0 #4a4a54,inset 0 3px 0 #a3a3ae;text-shadow:2px 2px 0 var(--ink)}\n.topbar{display:flex;align-items:center;gap:10px;position:fixed;top:clamp(14px,2.5vw,26px);right:clamp(14px,2.5vw,26px);z-index:5}\n.chip{display:flex;align-items:center;gap:8px;padding:10px 12px;background:rgba(13,10,36,.8);border:3px solid var(--ink);\n  box-shadow:inset 0 0 0 2px #3b3470,4px 4px 0 rgba(0,0,0,.45);font-size:13px;font-weight:700}\n.chip[hidden]{display:none}\n.chip i{width:14px;height:14px;background:var(--grass);box-shadow:inset -3px -3px 0 var(--grass-d),inset 3px 3px 0 var(--grass-l)}\n.profile{display:flex;align-items:center;gap:10px;padding:6px 12px 6px 6px;background:rgba(13,10,36,.8);border:3px solid var(--ink);\n  box-shadow:inset 0 0 0 2px #3b3470,4px 4px 0 rgba(0,0,0,.45);font-size:14px;font-weight:700}\n.profile:hover{background:rgba(40,30,90,.9)}\n#head{width:34px;height:34px;image-rendering:pixelated;border:2px solid var(--ink);display:block}\n.profile b{font-size:11px;opacity:.8}\n.menu{position:absolute;right:0;top:calc(100% + 8px);min-width:210px;background:#1d1848;border:3px solid var(--ink);\n  box-shadow:inset 0 0 0 2px #4b4392,6px 6px 0 rgba(0,0,0,.45);display:grid}\n.menu[hidden]{display:none}\n.menu button{padding:12px 14px;text-align:left;font-size:13px;background:none;border:0;border-bottom:2px solid #3b3470}\n.menu button:last-child{border-bottom:0}\n.menu button:hover{background:var(--grass-d)}\n#nameErr{color:#ffb4b4;font-size:12px;min-height:16px;margin-top:8px}\n.who{display:none}\n.hero{flex:1;min-height:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px}\n#skin{image-rendering:pixelated;animation:bob 2.4s steps(4) infinite}\n@keyframes bob{50%{transform:translateY(-6px)}}\n.skinbtns{display:flex;gap:8px}\n#open{position:fixed;left:clamp(14px,2.5vw,26px);bottom:clamp(14px,2.5vw,26px);z-index:5;padding:10px 16px;font-size:14px}\n.tabs{display:flex;gap:8px;margin-bottom:12px}\n.tab{padding:8px 14px;font-size:13px;font-weight:700;background:#6e6e78;border:3px solid var(--ink);box-shadow:inset 0 -3px 0 #4a4a54}\n.tab.on{background:var(--grass-d);box-shadow:inset 0 -3px 0 #2a5a14}\n#modsDlg{width:min(580px,94vw);max-height:88vh;overflow:auto}\n.mlist{max-height:300px;overflow:auto;padding-right:4px}\n.mrow{display:flex;align-items:center;gap:10px;padding:8px;margin-top:8px;font-size:13px;background:var(--ink);border:3px solid #3b3470}\n.mname{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.mico{width:36px;height:36px;flex:none;image-rendering:pixelated;background:#3b3470;display:grid;place-items:center;font-size:16px;font-weight:700}\n.mrow img{width:36px;height:36px;flex:none;background:#3b3470}\n.mrow .info{flex:1;min-width:0}.mrow .info b{display:block}\n.mrow .info small{display:block;opacity:.7;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.empty{opacity:.7;font-size:13px;padding:14px 0}\n.hint{font-size:12px;opacity:.75;margin-top:10px}\n#modsMsg{font-size:12px;min-height:16px;margin-top:10px}#modsMsg.err{color:#ffb4b4}\n.searchrow{display:flex;gap:8px}.searchrow input{flex:1}\n#quit{position:fixed;right:clamp(14px,2.5vw,26px);bottom:clamp(14px,2.5vw,26px);z-index:5;width:46px;height:46px;font-size:24px;font-weight:700;line-height:1;\n  background:#d63a3a;border:4px solid var(--ink);box-shadow:inset 0 -5px 0 #9c2222,inset 0 3px 0 #ff7a7a;text-shadow:2px 2px 0 #5a1010}\n#quit:hover{background:#ea4a4a}#quit:active{transform:translateY(3px)}\n.wrapTabs{flex-wrap:wrap}\n#friendsDlg,#modsDlg{width:min(580px,94vw);max-height:90vh;overflow:auto}\ninput[type=number]{width:100%;padding:10px;font:inherit;font-size:14px;color:var(--text);background:var(--ink);border:3px solid #4b4392}\n@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}\n</style>\n</head>\n<body>\n<canvas id=\"bg\" aria-hidden=\"true\"></canvas>\n\n<main>\n  <header class=\"brand\">\n    <h1>Cubeline</h1>\n    <p>Minecraft: Java Edition launcher</p>\n  </header>\n\n  <section class=\"hero\">\n    <canvas id=\"skin\" aria-label=\"Your Minecraft skin\"></canvas>\n    <div class=\"skinbtns\"><button class=\"mini\" id=\"skinBtn\">Change skin</button><button class=\"mini\" id=\"skinReset\">Reset</button></div>\n    <input type=\"file\" id=\"skinFile\" accept=\"image/png\" hidden>\n  </section>\n\n  <section class=\"dock\">\n    <div class=\"who\" id=\"who\"><i></i><span id=\"whoText\">Not signed in</span></div>\n    <div class=\"ver\" id=\"verLabel\">Minecraft: loading versions…</div>\n    <button class=\"ghost\" id=\"modsBtn\">Mods</button>\n    <button class=\"play\" id=\"play\">Play</button>\n    <div class=\"bar\" id=\"bar\" hidden><i id=\"fill\"></i></div>\n    <div id=\"status\" role=\"status\"></div>\n  </section>\n  <button class=\"ghost\" id=\"open\">Settings</button>\n  <button id=\"quit\" aria-label=\"Close Cubeline\" title=\"Close Cubeline\">&#10005;</button>\n</main>\n\n<div class=\"topbar\">\n  <div class=\"chip\" id=\"chip\" hidden title=\"Microsoft account\"><i></i><span id=\"msName\"></span></div>\n  <button class=\"profile\" id=\"profile\" aria-haspopup=\"true\" aria-expanded=\"false\">\n    <canvas id=\"head\" width=\"8\" height=\"8\" aria-hidden=\"true\"></canvas>\n    <span id=\"nick\">Player</span><b>&#9660;</b>\n  </button>\n  <div class=\"menu\" id=\"menu\" hidden>\n    <button id=\"mName\">Change name</button>\n    <button id=\"mSettings\">Settings</button>\n    <button id=\"mAcct\">Sign in with Microsoft</button>\n  </div>\n</div>\n\n<dialog id=\"welcome\">\n  <h2 id=\"wTitle\">Welcome! Pick your name</h2>\n  <label for=\"nameIn\">Your name</label>\n  <input type=\"text\" id=\"nameIn\" maxlength=\"16\" autocomplete=\"off\" placeholder=\"3 to 16 letters, numbers or _\">\n  <div id=\"nameErr\" role=\"alert\"></div>\n  <div class=\"actions\">\n    <button class=\"close\" id=\"wCancel\" hidden>Cancel</button>\n    <button class=\"save\" id=\"wSave\">Continue</button>\n  </div>\n</dialog>\n\n<dialog id=\"modsDlg\">\n  <div class=\"tabs wrapTabs\">\n    <button class=\"tab on\" id=\"kAll\">All</button><button class=\"tab\" id=\"kMods\">Mods</button><button class=\"tab\" id=\"kShaders\">Shaders</button><button class=\"tab\" id=\"kPacks\">Resource packs</button>\n  </div>\n  <h2 id=\"modsTitle\">Installed</h2>\n  <div class=\"hint\" id=\"kindHint\"></div>\n  <div id=\"loaderRow\">\n    <label for=\"loader\">Mod loader</label>\n    <select id=\"loader\"><option value=\"vanilla\">Vanilla (no mods)</option><option value=\"fabric\">Fabric (mods on)</option></select>\n    <div class=\"hint\" id=\"loaderHint\"></div>\n  </div>\n  <div class=\"tabs\" style=\"margin-top:16px\">\n    <button class=\"tab on\" id=\"tabInst\">Installed</button><button class=\"tab\" id=\"tabBrowse\">Browse library</button>\n  </div>\n  <div id=\"paneInst\">\n    <div class=\"mlist\" id=\"modList\"></div>\n    <button class=\"mini\" id=\"modAdd\" style=\"margin-top:12px\">Add from files…</button>\n  </div>\n  <div id=\"paneBrowse\" hidden>\n    <div class=\"searchrow\"><input type=\"text\" id=\"modQ\" placeholder=\"Search mods (Modrinth)\"><button class=\"mini\" id=\"modGo\">Search</button></div>\n    <div class=\"mlist\" id=\"modRes\" style=\"margin-top:6px\"></div>\n  </div>\n  <div id=\"modsMsg\" role=\"status\"></div>\n  <div class=\"actions\"><button class=\"close\" id=\"modsClose\">Close</button></div>\n</dialog>\n\n\n<dialog id=\"dlg\">\n  <h2>Settings</h2>\n\n  <label for=\"version\">Game version</label>\n  <select id=\"version\"></select>\n  <div class=\"row\"><input type=\"checkbox\" id=\"snaps\"><label for=\"snaps\" style=\"margin:0\">Include snapshots and pre-releases</label></div>\n\n  <label for=\"ram\">Memory: <span id=\"ramVal\">4</span> GB</label>\n  <input type=\"range\" id=\"ram\" min=\"2\" max=\"16\" step=\"1\" value=\"4\">\n\n  <label for=\"java\">Java path (optional)</label>\n  <input type=\"text\" id=\"java\" placeholder=\"Leave empty to use the Java on this computer\">\n\n  <label for=\"mode\">Play mode</label>\n  <select id=\"mode\"><option value=\"microsoft\">Microsoft account (online)</option><option value=\"offline\">Offline (just my name)</option></select>\n\n  <div class=\"acct\">\n    <span id=\"acctText\">Not signed in</span>\n    <button class=\"mini\" id=\"acctBtn\">Sign in</button>\n  </div>\n\n  <div class=\"actions\">\n    <button class=\"close\" id=\"close\">Close</button>\n    <button class=\"save\" id=\"save\">Save</button>\n  </div>\n</dialog>\n\n<script>\nconst { ipcRenderer } = require('electron');\nconst api = {\n  settings: () => ipcRenderer.invoke('settings:get'),\n  saveSettings: s => ipcRenderer.invoke('settings:save', s),\n  versions: n => ipcRenderer.invoke('versions', n),\n  account: () => ipcRenderer.invoke('account:get'),\n  login: () => ipcRenderer.invoke('account:login'),\n  logout: () => ipcRenderer.invoke('account:logout'),\n  play: v => ipcRenderer.invoke('play', v),\n  itemsList: (k, v) => ipcRenderer.invoke('items:list', k, v), itemsAdd: (k, v) => ipcRenderer.invoke('items:add', k, v),\n  itemsToggle: (k, v, f) => ipcRenderer.invoke('items:toggle', k, v, f), itemsRemove: (k, v, f) => ipcRenderer.invoke('items:remove', k, v, f),\n  itemsSearch: (k, q, v) => ipcRenderer.invoke('items:search', k, q, v), itemsInstall: (k, id, v) => ipcRenderer.invoke('items:install', k, id, v),\n  itemsEnrich: (k, v) => ipcRenderer.invoke('items:enrich', k, v),\n  uploadSkin: (d, slim) => ipcRenderer.invoke('skin:upload', d, slim),\n  on: (ch, cb) => ipcRenderer.on(ch, (_, d) => cb(d))\n};\n/* ---------- Background: dusk over a blocky world ---------- */\nconst cv = document.getElementById('bg'), cx = cv.getContext('2d');\nconst B = 16; let W, H;\nconst size = () => { W = cv.width = innerWidth; H = cv.height = innerHeight; };\naddEventListener('resize', size); size();\nconst rng = s => () => (s = Math.imul(s ^ s >>> 15, 1 | s), s = s + Math.imul(s ^ s >>> 7, 61 | s) ^ s, ((s ^ s >>> 14) >>> 0) / 4294967296);\nconst layers = [\n  { c: '#3a2470', y: .58, amp: 5, v: .12, seed: 7 },\n  { c: '#271a58', y: .70, amp: 7, v: .3,  seed: 11 },\n  { c: '#160f36', y: .82, amp: 9, v: .6,  seed: 23, top: '#3d7a22' }\n].map(l => {\n  const r = rng(l.seed); let h = 0, cols = [];\n  for (let i = 0; i < 200; i++) { h = Math.max(-l.amp, Math.min(l.amp, h + Math.round((r() - .5) * 3))); cols.push(h); }\n  return { ...l, cols: cols.concat(cols.slice().reverse()) };\n});\nconst rs = rng(5);\nconst stars = Array.from({ length: 90 }, () => ({ x: rs(), y: rs() * .55, p: rs() * 6 }));\nconst clouds = Array.from({ length: 5 }, (_, i) => ({ x: rs(), y: .1 + rs() * .25, w: 5 + Math.floor(rs() * 5), v: .15 + rs() * .2 }));\nlet t = 0;\nfunction draw() {\n  t++;\n  const g = cx.createLinearGradient(0, 0, 0, H);\n  g.addColorStop(0, '#14103a'); g.addColorStop(.55, '#4a2a7a'); g.addColorStop(1, '#ff8a8a');\n  cx.fillStyle = g; cx.fillRect(0, 0, W, H);\n  for (const s of stars) {\n    cx.fillStyle = `rgba(255,248,220,${.35 + .45 * Math.abs(Math.sin(t / 50 + s.p))})`;\n    cx.fillRect(Math.floor(s.x * W / 4) * 4, Math.floor(s.y * H / 4) * 4, 4, 4);\n  }\n  const mx = Math.round(W * .78 / B) * B, my = Math.round(H * .16 / B) * B;\n  cx.fillStyle = '#fff3cf'; cx.fillRect(mx, my, B * 4, B * 4);\n  cx.fillStyle = '#e8d9a8'; cx.fillRect(mx + B, my + B, B, B); cx.fillRect(mx + B * 2, my + B * 2, B, B);\n  cx.fillStyle = 'rgba(255,255,255,.16)';\n  for (const c of clouds) {\n    const x = ((c.x * W + t * c.v) % (W + 300)) - 150, y = Math.round(c.y * H / B) * B;\n    cx.fillRect(Math.round(x / B) * B, y, c.w * B, B); cx.fillRect(Math.round(x / B) * B + B, y - B, (c.w - 2) * B, B);\n  }\n  for (const l of layers) {\n    const off = t * l.v, n = l.cols.length;\n    for (let x = -B; x < W + B; x += B) {\n      const i = Math.floor((x + off) / B + n * 1000) % n;\n      const top = Math.round((H * l.y + l.cols[i] * B) / B) * B;\n      const px = x - (off % B);\n      cx.fillStyle = l.c; cx.fillRect(px, top, B + 1, H - top);\n      if (l.top) { cx.fillStyle = l.top; cx.fillRect(px, top, B + 1, 6); }\n    }\n  }\n}\ndraw();\nif (!matchMedia('(prefers-reduced-motion: reduce)').matches) (function loop() { draw(); requestAnimationFrame(loop); })();\n\n/* ---------- Launcher logic ---------- */\nconst $ = id => document.getElementById(id);\nlet S = {}, versions = [], player = null;\n\n/* Skin: default Steve is generated; any 64x64 or 64x32 PNG can replace it */\nfunction makeSteve() {\n  const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d');\n  const R = (col, x, y, w, h) => { g.fillStyle = col; g.fillRect(x, y, w, h); };\n  const f = { H: '#4a3322', h: '#5d4129', S: '#c08a66', s: '#a8704f', W: '#ffffff', B: '#3b3fa8', M: '#6b3f2a' };\n  ['HHHHHHHH', 'HHHhHHHH', 'HSSSSSSH', 'SWBSSBWS', 'SSSssSSS', 'SSMMMMSS', 'SSSSSSSS', 'sSSSSSSs']\n    .forEach((r, y) => [...r].forEach((k, x) => R(f[k], 8 + x, 8 + y, 1, 1)));\n  R('#00a8a8', 20, 20, 8, 12);\n  [[44, 20], [36, 52]].forEach(([x, y]) => { R('#c08a66', x, y, 4, 12); R('#00a8a8', x, y, 4, 4); });\n  [[4, 20], [20, 52]].forEach(([x, y]) => { R('#3d3d9e', x, y, 4, 12); R('#6b6b6b', x, y + 10, 4, 2); });\n  return c;\n}\nlet skinSrc = makeSteve(), legacy = false, slim = false;\nfunction drawSkin(cv, s) {\n  cv.width = 16 * s; cv.height = 32 * s;\n  const g = cv.getContext('2d'); g.imageSmoothingEnabled = false;\n  const put = (sx, sy, pw, ph, dx, dy, flip) => {\n    g.save();\n    if (flip) { g.translate((dx + pw) * s, dy * s); g.scale(-1, 1); g.drawImage(skinSrc, sx, sy, pw, ph, 0, 0, pw * s, ph * s); }\n    else g.drawImage(skinSrc, sx, sy, pw, ph, dx * s, dy * s, pw * s, ph * s);\n    g.restore();\n  };\n  const arm2 = legacy ? [44, 20, 4, 12, 12, 8, true] : [36, 52, 4, 12, 12, 8, false];\n  const leg2 = legacy ? [4, 20, 4, 12, 8, 20, true] : [20, 52, 4, 12, 8, 20, false];\n  put(4, 20, 4, 12, 4, 20); put(...leg2);\n  put(44, 20, 4, 12, 0, 8); put(...arm2);\n  put(20, 20, 8, 12, 4, 8); put(8, 8, 8, 8, 4, 0);\n  if (!legacy) { put(4, 36, 4, 12, 4, 20); put(4, 52, 4, 12, 8, 20); put(44, 36, 4, 12, 0, 8); put(52, 52, 4, 12, 12, 8); put(20, 36, 8, 12, 4, 8); }\n  put(40, 8, 8, 8, 4, 0);\n}\nfunction drawHead() {\n  const g = $('head').getContext('2d'); g.imageSmoothingEnabled = false; g.clearRect(0, 0, 8, 8);\n  g.drawImage(skinSrc, 8, 8, 8, 8, 0, 0, 8, 8); g.drawImage(skinSrc, 40, 8, 8, 8, 0, 0, 8, 8);\n}\nfunction renderSkin() {\n  const hero = document.querySelector('.hero');\n  drawSkin($('skin'), Math.max(4, Math.min(12, Math.floor((hero.clientHeight - 70) / 32)))); drawHead();\n}\nnew ResizeObserver(renderSkin).observe(document.querySelector('.hero'));\nfunction useSkin(img) {\n  if (img.width !== 64 || (img.height !== 64 && img.height !== 32)) return false;\n  const c = document.createElement('canvas'); c.width = c.height = 64; c.getContext('2d').drawImage(img, 0, 0);\n  skinSrc = c; legacy = img.height === 32;\n  slim = !legacy && c.getContext('2d').getImageData(54, 20, 1, 1).data[3] === 0; /* slim (Alex) skins have a transparent column here */\n  renderSkin(); return true;\n}\n$('skinBtn').onclick = () => $('skinFile').click();\n$('skinFile').onchange = e => {\n  const file = e.target.files[0]; e.target.value = ''; if (!file) return;\n  const r = new FileReader();\n  r.onload = () => {\n    const img = new Image();\n    img.onload = async () => {\n      if (useSkin(img)) { S.skin = r.result; S.slim = slim; await api.saveSettings(S); await pushSkin(false); }\n      else setStatus('Skin must be a 64x64 or 64x32 PNG file.', true);\n    };\n    img.src = r.result;\n  };\n  r.readAsDataURL(file);\n};\n$('skinReset').onclick = async () => { skinSrc = makeSteve(); legacy = false; slim = false; S.skin = ''; S.slim = false; await api.saveSettings(S); renderSkin(); await pushSkin(true); };\n/* Make the skin show in the real game */\nasync function pushSkin(reset) {\n  if (S.mode === 'microsoft') {\n    setStatus('Sending skin to your Microsoft account…');\n    const r = await api.uploadSkin(reset ? '' : S.skin, slim);\n    setStatus(r.ok ? (reset ? 'Skin reset on your account.' : 'Skin uploaded. It will show in the game.') : r.error, !r.ok);\n  } else setStatus(reset ? '' : 'Skin saved. It will show in the game when you press Play.');\n}\n\n/* Name (profile) */\nconst NAME_RE = /^[A-Za-z0-9_]{3,16}$/;\nfunction askName(first) {\n  $('wTitle').textContent = first ? 'Welcome! Pick your name' : 'Change your name';\n  $('nameIn').value = first ? '' : (S.name || '');\n  $('nameErr').textContent = ''; $('wCancel').hidden = first;\n  $('welcome').showModal(); $('nameIn').focus();\n}\nasync function submitName() {\n  const v = $('nameIn').value.trim();\n  if (!NAME_RE.test(v)) { $('nameErr').textContent = 'Use 3 to 16 letters, numbers or _ (no spaces).'; return; }\n  S.name = v; await api.saveSettings(S); $('nick').textContent = v; $('welcome').close();\n}\n$('wSave').onclick = submitName;\n$('wCancel').onclick = () => $('welcome').close();\n$('nameIn').onkeydown = e => { if (e.key === 'Enter') submitName(); };\n$('welcome').addEventListener('cancel', e => { if (!S.name) e.preventDefault(); });\n\n/* Mini menu */\nconst toggleMenu = open => { $('menu').hidden = !open; $('profile').setAttribute('aria-expanded', open); };\n$('profile').onclick = e => { e.stopPropagation(); toggleMenu($('menu').hidden); };\ndocument.addEventListener('click', () => toggleMenu(false));\ndocument.addEventListener('keydown', e => { if (e.key === 'Escape') toggleMenu(false); });\n$('mName').onclick = () => askName(false);\n$('mSettings').onclick = () => $('dlg').showModal();\n$('mAcct').onclick = () => $('acctBtn').click();\n\nfunction setPlayer(name) {\n  player = name || null;\n  $('who').classList.toggle('on', !!player);\n  $('whoText').textContent = player ? `Signed in as ${player}` : 'Not signed in';\n  $('acctText').textContent = $('whoText').textContent;\n  $('acctBtn').textContent = player ? 'Sign out' : 'Sign in';\n  $('chip').hidden = !player; $('msName').textContent = player || '';\n  $('mAcct').textContent = player ? 'Sign out of Microsoft' : 'Sign in with Microsoft';\n}\nfunction applyMode() {\n  const off = $('mode').value === 'offline';\n  document.querySelector('.acct').style.display = off ? 'none' : '';\n  $('mAcct').hidden = off; $('chip').hidden = off || !player;\n}\n$('mode').onchange = applyMode;\nfunction setStatus(msg, err) { $('status').textContent = msg || ''; $('status').classList.toggle('err', !!err); }\nfunction updateLabel() {\n  $('verLabel').textContent = S.version ? `Minecraft ${S.version}${S.loader === 'fabric' ? ' · Fabric' : ''}` : 'Minecraft: pick a version in Settings';\n  refreshMods();\n}\n\n/* ---------- Mods, shaders and resource packs ---------- */\nlet kind = 'all';\nconst KIND_LIST = ['mods', 'shaders', 'packs'];\nconst LABEL = { mods: 'mod', shaders: 'shader', packs: 'resource pack' };\nconst BADGE = { mods: 'Mod', shaders: 'Shader', packs: 'Pack' };\nconst TITLE = { all: 'Installed', mods: 'Mods', shaders: 'Shaders', packs: 'Resource packs' };\nconst HINT = {\n  all: 'Everything installed for this version. Pick a tab above to add more.',\n  mods: 'Mods only load with Fabric. Adding a mod switches the loader to Fabric.',\n  shaders: 'Shaders run through Iris, which Cubeline installs for you when you press Play. Only one shader is active: the first one that is switched on.',\n  packs: 'Resource packs change textures and sounds. Enabled packs load when you press Play.'\n};\nconst el = (tag, props, ...kids) => { const e = document.createElement(tag); Object.assign(e, props || {}); e.append(...kids); return e; };\nconst modMsg = (m, err) => { $('modsMsg').textContent = m || ''; $('modsMsg').classList.toggle('err', !!err); };\nasync function refreshMods() {\n  const ks = kind === 'all' ? KIND_LIST : [kind];\n  const list = [];\n  if (S.version) for (const k of ks) for (const m of await api.itemsList(k, S.version)) list.push({ ...m, k });\n  for (const [id, k] of [['kAll', 'all'], ['kMods', 'mods'], ['kShaders', 'shaders'], ['kPacks', 'packs']]) $(id).classList.toggle('on', kind === k);\n  $('modsTitle').textContent = TITLE[kind]; $('kindHint').textContent = HINT[kind];\n  $('loaderRow').hidden = kind !== 'mods';\n  $('loader').value = S.loader || 'vanilla';\n  $('loaderHint').textContent = S.loader === 'fabric' ? 'Fabric is installed automatically when you press Play.' : 'Adding a mod switches this to Fabric.';\n  const what = kind === 'packs' ? 'resource packs' : kind === 'shaders' ? 'shaders' : 'mods';\n  $('modAdd').hidden = kind === 'all'; $('modAdd').textContent = `Add ${what} from files…`;\n  $('modQ').placeholder = `Search ${what} (Modrinth)`;\n  for (const k of ks) if (S.version && list.some(m => m.k === k && !m.icon)) api.itemsEnrich(k, S.version).then(r => { if (r.changed) refreshMods(); });\n  const box = $('modList'); box.textContent = '';\n  if (!list.length) {\n    box.append(el('div', { className: 'empty', textContent: kind === 'all' ? `Nothing installed for Minecraft ${S.version || '?'} yet.` : `No ${LABEL[kind]}s for Minecraft ${S.version || '?'} yet. Add from files or browse the library.` }));\n    return;\n  }\n  for (const m of list) {\n    const chk = el('input', { type: 'checkbox', checked: m.enabled, title: 'On / off' });\n    chk.onchange = async () => { await api.itemsToggle(m.k, S.version, m.file); refreshMods(); };\n    const rm = el('button', { className: 'mini', textContent: 'Remove' });\n    rm.onclick = async () => { await api.itemsRemove(m.k, S.version, m.file); refreshMods(); };\n    const pic = m.icon ? el('img', { className: 'mico', src: m.icon, alt: '' }) : el('div', { className: 'mico', textContent: (m.title || m.name || '?')[0].toUpperCase() });\n    const name = (kind === 'all' ? `[${BADGE[m.k]}] ` : '') + (m.title || m.name);\n    box.append(el('div', { className: 'mrow' }, chk, pic, el('span', { className: 'mname', textContent: name, title: m.file }), rm));\n  }\n}\nasync function needFabric() { if (S.loader !== 'fabric') { S.loader = 'fabric'; await api.saveSettings(S); } }\nfunction showTab(browse) {\n  $('paneInst').hidden = browse; $('paneBrowse').hidden = !browse;\n  $('tabInst').classList.toggle('on', !browse); $('tabBrowse').classList.toggle('on', browse); modMsg('');\n  if (browse && !$('modRes').children.length) searchMods();\n}\nasync function searchMods() {\n  if (kind === 'all') return;\n  if (!S.version) { modMsg('Pick a version in Settings first.', true); return; }\n  const box = $('modRes'); box.textContent = ''; modMsg('Searching…');\n  const r = await api.itemsSearch(kind, $('modQ').value.trim(), S.version);\n  if (r.error) { modMsg(r.error, true); return; }\n  modMsg(r.hits.length ? '' : `Nothing found for Minecraft ${S.version}.`);\n  for (const h of r.hits) {\n    const btn = el('button', { className: 'mini', textContent: 'Install' });\n    btn.onclick = async () => {\n      btn.disabled = true; btn.textContent = 'Installing…'; modMsg('');\n      const x = await api.itemsInstall(kind, h.id, S.version);\n      if (x.error) { btn.disabled = false; btn.textContent = 'Install'; modMsg(x.error, true); return; }\n      if (kind === 'mods') await needFabric();\n      btn.textContent = 'Installed ✓'; modMsg(x.got.length ? 'Installed: ' + x.got.join(', ') : 'Already installed.'); refreshMods();\n    };\n    const img = el('img', { alt: '', loading: 'lazy' }); if (h.icon) img.src = h.icon;\n    box.append(el('div', { className: 'mrow' }, img, el('div', { className: 'info' }, el('b', { textContent: h.title }), el('small', { textContent: h.desc || '' })), btn));\n  }\n}\nfunction setKind(k) {\n  kind = k; $('modRes').textContent = '';\n  $('tabBrowse').hidden = k === 'all';\n  showTab(false); refreshMods();\n}\n$('kAll').onclick = () => setKind('all');\n$('kMods').onclick = () => setKind('mods');\n$('kShaders').onclick = () => setKind('shaders');\n$('kPacks').onclick = () => setKind('packs');\n$('modsBtn').onclick = () => { showTab(false); refreshMods(); $('modsDlg').showModal(); };\n$('modsClose').onclick = () => $('modsDlg').close();\n$('tabInst').onclick = () => showTab(false);\n$('tabBrowse').onclick = () => showTab(true);\n$('modGo').onclick = searchMods;\n$('modQ').onkeydown = e => { if (e.key === 'Enter') searchMods(); };\n$('loader').onchange = async e => { S.loader = e.target.value; await api.saveSettings(S); updateLabel(); };\n$('modAdd').onclick = async () => {\n  if (!S.version) { modMsg('Pick a version in Settings first.', true); return; }\n  const r = await api.itemsAdd(kind, S.version);\n  if (r.added && kind === 'mods') await needFabric();\n  if (r.added) modMsg(`Added ${r.added} ${LABEL[kind]}(s) for Minecraft ${S.version}.`);\n  refreshMods();\n};\n\nasync function loadVersions() {\n  const r = await api.versions($('snaps').checked);\n  const sel = $('version'); sel.innerHTML = '';\n  versions = r.list || [];\n  if (!versions.length) {\n    sel.innerHTML = `<option value=\"\">${r.error ? 'Cannot reach Mojang. Check your internet.' : 'No versions found'}</option>`;\n    return;\n  }\n  for (const v of versions) {\n    const o = document.createElement('option');\n    o.value = v.id; o.textContent = v.type === 'release' ? v.id : `${v.id} (${v.type})`; sel.appendChild(o);\n  }\n  sel.value = versions.some(v => v.id === S.version) ? S.version : versions[0].id;\n}\n\n$('quit').onclick = () => ipcRenderer.invoke('app:quit');\n$('open').onclick = () => $('dlg').showModal();\n$('close').onclick = () => $('dlg').close();\n$('ram').oninput = e => $('ramVal').textContent = e.target.value;\n$('snaps').onchange = loadVersions;\n$('save').onclick = async () => {\n  S = { ...S, version: $('version').value, ram: +$('ram').value, javaPath: $('java').value.trim(), snapshots: $('snaps').checked, mode: $('mode').value };\n  await api.saveSettings(S); applyMode(); updateLabel(); $('dlg').close();\n};\n$('acctBtn').onclick = async () => {\n  if (player) { await api.logout(); setPlayer(null); }\n  else { $('acctBtn').disabled = true; setPlayer(await api.login()); $('acctBtn').disabled = false; }\n};\n\n$('play').onclick = async () => {\n  if (!S.version) { setStatus('Pick a version first.', true); $('dlg').showModal(); return; }\n  $('play').disabled = true; $('bar').hidden = false; $('fill').style.width = '4%'; setStatus('Getting ready…');\n  const r = await api.play(S.version);\n  if (r && r.error) { setStatus(r.error, true); $('play').disabled = false; $('bar').hidden = true; }\n};\napi.on('account', setPlayer);\napi.on('warn', m => setStatus(m, true));\napi.on('crash', m => setStatus('Minecraft closed: ' + m, true));\napi.on('progress', p => { $('fill').style.width = Math.max(4, p.pct) + '%'; setStatus(`Downloading ${p.type}: ${p.pct}%`); });\napi.on('state', s => {\n  if (s === 'running') { $('bar').hidden = true; setStatus('Minecraft is running. Have fun!'); }\n  else { $('play').disabled = false; $('bar').hidden = true; setStatus(s.endsWith(':0') ? '' : 'Minecraft closed unexpectedly. Check your Java version in Settings.', !s.endsWith(':0')); }\n});\n\n(async () => {\n  S = await api.settings();\n  $('nick').textContent = S.name || 'Player';\n  if (S.skin) { const i = new Image(); i.onload = () => useSkin(i); i.src = S.skin; }\n  if (!S.name) askName(true);\n  $('mode').value = S.mode || 'offline'; $('ram').value = S.ram; $('ramVal').textContent = S.ram; $('java').value = S.javaPath || ''; $('snaps').checked = !!S.snapshots;\n  await loadVersions();\n  if (!S.version && versions.length) { S.version = versions[0].id; api.saveSettings(S); }\n  updateLabel();\n  setPlayer(await api.account()); applyMode();\n})();\n</script>\n</body>\n</html>\n";

const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const http = require('http');
const zlib = require('zlib');
const { Client } = require('minecraft-launcher-core');
const { Auth } = require('msmc');

const MANIFEST = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const defaults = { version: '', ram: 4, javaPath: '', snapshots: false, token: '', mode: 'offline', name: '', skin: '', slim: false, loader: 'vanilla' };
const cfgFile = () => path.join(app.getPath('userData'), 'settings.json');
const load = () => { try { return { ...defaults, ...JSON.parse(fs.readFileSync(cfgFile(), 'utf8')) }; } catch { return { ...defaults }; } };
const save = (s) => fs.writeFileSync(cfgFile(), JSON.stringify(s, null, 2));

let win, account = null, running = false;
const send = (ch, data) => win && !win.isDestroyed() && win.webContents.send(ch, data);

function createWindow() {
  win = new BrowserWindow({
    width: 1040, height: 660, minWidth: 800, minHeight: 560,
    autoHideMenuBar: true, backgroundColor: '#14103a', title: 'Cubeline',
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });
  win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(HTML));
}

async function signIn(interactive = true) {
  const auth = new Auth('select_account');
  const s = load();
  let xbox;
  if (s.token) { try { xbox = await auth.refresh(s.token); } catch { xbox = null; } }
  if (!xbox && interactive) xbox = await auth.launch('electron');
  if (!xbox) return null;
  account = await xbox.getMinecraft();
  save({ ...load(), token: xbox.save() });
  return account.profile.name;
}

ipcMain.handle('settings:get', () => { const { token, ...s } = load(); return s; });
ipcMain.handle('settings:save', (_, s) => { save({ ...load(), ...s }); return true; });

ipcMain.handle('versions', async (_, snapshots) => {
  try {
    const m = await (await fetch(MANIFEST)).json();
    const list = m.versions
      .filter(v => v.type === 'release' || (snapshots && v.type === 'snapshot'))
      .map(v => ({ id: v.id, type: v.type }));
    return { list };
  } catch (e) { return { list: [], error: String(e.message || e) }; }
});

ipcMain.handle('account:get', async () => { try { return await signIn(false); } catch { return null; } });
ipcMain.handle('account:login', async () => { try { return await signIn(true); } catch (e) { return null; } });
ipcMain.handle('account:logout', () => { account = null; save({ ...load(), token: '' }); return true; });

/* ---------- Skin in the real game ----------
   Online mode: the skin is uploaded to the Microsoft account (skin:upload below).
   Offline mode: the game only asks a skin server for textures, so we run a tiny one on 127.0.0.1
   and point the game at it with authlib-injector (a small helper jar, downloaded once). */
const skinPng = s => (s.skin && s.skin.startsWith('data:image/png;base64,')) ? Buffer.from(s.skin.split(',')[1], 'base64') : null;
let skinServer = null;
const stopSkinServer = () => { if (skinServer) { skinServer.close(); skinServer = null; } };

async function ensureInjector() {
  const f = path.join(app.getPath('userData'), 'authlib-injector.jar');
  if (fs.existsSync(f)) return f;
  const urls = [];
  try { urls.push((await (await fetch('https://authlib-injector.yushi.moe/artifact/latest.json')).json()).download_url); } catch {}
  try {
    const rel = await (await fetch('https://api.github.com/repos/yushijinhun/authlib-injector/releases/latest', { headers: { 'User-Agent': 'Cubeline' } })).json();
    const a = (rel.assets || []).find(x => /\.jar$/.test(x.name)); if (a) urls.push(a.browser_download_url);
  } catch {}
  let buf = null;
  for (const url of urls.filter(Boolean)) {
    try { const b = Buffer.from(await (await fetch(url)).arrayBuffer()); if (b.length > 10000 && b[0] === 0x50 && b[1] === 0x4b) { buf = b; break; } } catch {}
  }
  if (!buf) throw new Error('Could not download the skin helper.');
  fs.writeFileSync(f + '.tmp', buf); fs.renameSync(f + '.tmp', f);
  return f;
}

function startSkinServer() {
  return new Promise((resolve, reject) => {
    const srv = http.createServer((req, res) => {
      const u = req.url.split('?')[0], s = load(), png = skinPng(s);
      const hash = png ? crypto.createHash('sha1').update(png).digest('hex') : '';
      const json = o => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
      if (u === '/') return json({ meta: { serverName: 'Cubeline', implementationName: 'cubeline', implementationVersion: '1.0.0' }, skinDomains: ['127.0.0.1'] });
      if (png && u === '/textures/' + hash) { res.writeHead(200, { 'Content-Type': 'image/png' }); return res.end(png); }
      const m = u.match(/^\/sessionserver\/session\/minecraft\/profile\/([0-9a-fA-F-]{32,36})$/);
      if (m) {
        const id = m[1].replace(/-/g, '').toLowerCase(), textures = {};
        if (png) textures.SKIN = { url: `http://127.0.0.1:${srv.address().port}/textures/${hash}`, ...(s.slim ? { metadata: { model: 'slim' } } : {}) };
        const value = Buffer.from(JSON.stringify({ timestamp: Date.now(), profileId: id, profileName: s.name, textures })).toString('base64');
        return json({ id, name: s.name, properties: [{ name: 'textures', value }] });
      }
      res.writeHead(404); res.end();
    });
    srv.once('error', reject);
    srv.listen(0, '127.0.0.1', () => { skinServer = srv; resolve(srv.address().port); });
  });
}

ipcMain.handle('skin:upload', async (_, dataUrl, slim) => {
  try {
    if (!account) {
      const name = await signIn(true);
      if (!name) return { error: 'Sign in with Microsoft first.' };
      send('account', name);
    }
    const headers = { Authorization: 'Bearer ' + account.mclc().access_token };
    const base = 'https://api.minecraftservices.com/minecraft/profile/skins';
    let r;
    if (!dataUrl) r = await fetch(base + '/active', { method: 'DELETE', headers });
    else {
      const fd = new FormData();
      fd.append('variant', slim ? 'slim' : 'classic');
      fd.append('file', new Blob([Buffer.from(dataUrl.split(',')[1], 'base64')], { type: 'image/png' }), 'skin.png');
      r = await fetch(base, { method: 'POST', headers, body: fd });
    }
    return r.ok ? { ok: true } : { error: `Mojang refused the skin (error ${r.status}).` };
  } catch (e) { return { error: String(e.message || e) }; }
});

/* ---------- Java: downloaded from Mojang, the right one for each Minecraft version ---------- */
const RUNTIME_INDEX = 'https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json';
function runtimePlatform() {
  const p = process.platform, a = process.arch;
  if (p === 'win32') return a === 'arm64' ? 'windows-arm64' : a === 'ia32' ? 'windows-x86' : 'windows-x64';
  if (p === 'darwin') return a === 'arm64' ? 'mac-os-arm64' : 'mac-os';
  return a === 'ia32' ? 'linux-i386' : 'linux';
}
const sha1 = b => crypto.createHash('sha1').update(b).digest('hex');
async function ensureJava(versionUrl) {
  const vj = await (await fetch(versionUrl)).json();
  const comp = (vj.javaVersion && vj.javaVersion.component) || 'jre-legacy';
  const idx = await (await fetch(RUNTIME_INDEX)).json();
  const entry = ((idx[runtimePlatform()] || {})[comp] || [])[0];
  if (!entry) throw new Error(`Mojang has no ${comp} for this system.`);
  const dir = path.join(app.getPath('userData'), 'runtime', comp);
  const bin = process.platform === 'win32' ? path.join(dir, 'bin', 'java.exe')
    : process.platform === 'darwin' ? path.join(dir, 'jre.bundle', 'Contents', 'Home', 'bin', 'java') : path.join(dir, 'bin', 'java');
  const marker = path.join(dir, '.complete');
  if (fs.existsSync(bin) && fs.existsSync(marker) && fs.readFileSync(marker, 'utf8') === entry.manifest.sha1) return bin;

  const files = Object.entries((await (await fetch(entry.manifest.url)).json()).files);
  fs.mkdirSync(dir, { recursive: true });
  for (const [rel, f] of files) if (f.type === 'directory') fs.mkdirSync(path.join(dir, rel), { recursive: true });
  const todo = files.filter(([, f]) => f.type === 'file'), total = todo.length;
  let done = 0, i = 0;
  const worker = async () => {
    while (i < todo.length) {
      const [rel, f] = todo[i++], dest = path.join(dir, rel), raw = f.downloads.raw;
      let ok = false;
      try { ok = fs.existsSync(dest) && sha1(fs.readFileSync(dest)) === raw.sha1; } catch {}
      for (let t = 0; !ok && t < 3; t++) {
        try {
          const b = Buffer.from(await (await fetch(raw.url)).arrayBuffer());
          if (sha1(b) !== raw.sha1) continue;
          fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, b);
          if (f.executable && process.platform !== 'win32') fs.chmodSync(dest, 0o755);
          ok = true;
        } catch {}
      }
      if (!ok) throw new Error('Java download failed for ' + rel);
      send('progress', { type: 'Java', pct: Math.round(++done / total * 100) });
    }
  };
  await Promise.all(Array.from({ length: 8 }, worker));
  if (process.platform !== 'win32') for (const [rel, f] of files) if (f.type === 'link') { try { fs.symlinkSync(f.target, path.join(dir, rel)); } catch {} }
  if (!fs.existsSync(bin)) throw new Error('Java was downloaded but java was not found inside it.');
  fs.writeFileSync(marker, entry.manifest.sha1);
  return bin;
}

/* ---------- Mods, shaders and resource packs ----------
   Each kind keeps its files in <app data>/<folder>/<version>/ . A file that ends in .disabled is switched off.
   Mods need Fabric. Shaders need Iris (a Fabric mod that Cubeline installs for you). Resource packs need nothing. */
const KINDS = { mods: { dir: 'mods', ext: /\.jar(\.disabled)?$/ }, shaders: { dir: 'shaders', ext: /\.zip(\.disabled)?$/ }, packs: { dir: 'resourcepacks', ext: /\.zip(\.disabled)?$/ } };
const LOADERS = { mods: ['fabric'], shaders: ['iris'], packs: [] };
const LABELS = { mods: 'mod', shaders: 'shader', packs: 'resource pack' };
const itemsDir = (k, v) => path.join(app.getPath('userData'), KINDS[k].dir, String(v || 'none').replace(/[^\w.\- ]/g, '_'));
const okFile = (k, f) => typeof f === 'string' && f === path.basename(f) && KINDS[k].ext.test(f);
/* .meta.json remembers the title and icon of items installed from the library */
const metaPath = (k, v) => path.join(itemsDir(k, v), '.meta.json');
const readMeta = (k, v) => { try { return JSON.parse(fs.readFileSync(metaPath(k, v), 'utf8')); } catch { return {}; } };
const writeMeta = (k, v, m) => { fs.mkdirSync(itemsDir(k, v), { recursive: true }); fs.writeFileSync(metaPath(k, v), JSON.stringify(m)); };
function listItems(k, v) {
  const d = itemsDir(k, v);
  if (!fs.existsSync(d)) return [];
  const meta = readMeta(k, v);
  return fs.readdirSync(d).filter(f => okFile(k, f)).sort().map(f => {
    const base = f.replace(/\.disabled$/, '');
    return { file: f, name: base.replace(/\.(jar|zip)$/, ''), enabled: !f.endsWith('.disabled'), title: (meta[base] || {}).title || '', icon: (meta[base] || {}).icon || '' };
  });
}
ipcMain.handle('items:list', (_, k, v) => listItems(k, v));
ipcMain.handle('items:add', async (_, k, v) => {
  const r = await dialog.showOpenDialog(win, { title: 'Add ' + LABELS[k] + 's', properties: ['openFile', 'multiSelections'], filters: [{ name: LABELS[k] + 's', extensions: [k === 'mods' ? 'jar' : 'zip'] }] });
  if (!r.canceled) { const d = itemsDir(k, v); fs.mkdirSync(d, { recursive: true }); for (const f of r.filePaths) fs.copyFileSync(f, path.join(d, path.basename(f))); }
  return { list: listItems(k, v), added: r.canceled ? 0 : r.filePaths.length };
});
ipcMain.handle('items:toggle', (_, k, v, f) => {
  if (okFile(k, f)) { const a = path.join(itemsDir(k, v), f); fs.renameSync(a, f.endsWith('.disabled') ? a.slice(0, -9) : a + '.disabled'); }
  return listItems(k, v);
});
ipcMain.handle('items:remove', (_, k, v, f) => {
  if (okFile(k, f)) { fs.rmSync(path.join(itemsDir(k, v), f), { force: true }); const m = readMeta(k, v); delete m[f.replace(/\.disabled$/, '')]; writeMeta(k, v, m); }
  return listItems(k, v);
});

const MR = 'https://api.modrinth.com/v2', UA = { 'User-Agent': 'Cubeline/1.0 (Minecraft launcher)' };
async function projectMeta(pid) {
  const pj = await (await fetch(`${MR}/project/${encodeURIComponent(pid)}`, { headers: UA })).json();
  let icon = '';
  if (pj.icon_url) {
    const r = await fetch(pj.icon_url), b = Buffer.from(await r.arrayBuffer());
    if (b.length < 300000) icon = `data:${r.headers.get('content-type') || 'image/png'};base64,` + b.toString('base64');
  }
  return { title: pj.title || '', icon };
}
/* tiny zip reader: pull one file out of a .jar */
function zipRead(file, want) {
  const b = fs.readFileSync(file); let e = b.length - 22;
  while (e >= 0 && b.readUInt32LE(e) !== 0x06054b50) e--;
  if (e < 0) return null;
  let n = b.readUInt16LE(e + 10), p = b.readUInt32LE(e + 16);
  for (let i = 0; i < n && b.readUInt32LE(p) === 0x02014b50; i++) {
    const method = b.readUInt16LE(p + 10), csize = b.readUInt32LE(p + 20), nl = b.readUInt16LE(p + 28), xl = b.readUInt16LE(p + 30), cl = b.readUInt16LE(p + 32), lo = b.readUInt32LE(p + 42);
    if (b.toString('utf8', p + 46, p + 46 + nl) === want) {
      const start = lo + 30 + b.readUInt16LE(lo + 26) + b.readUInt16LE(lo + 28), data = b.subarray(start, start + csize);
      return method === 0 ? data : zlib.inflateRawSync(data);
    }
    p += 46 + nl + xl + cl;
  }
  return null;
}
/* give every item without a picture one: mods first from inside the jar, then from Modrinth by file hash */
async function enrich(k, v) {
  const d = itemsDir(k, v); if (!fs.existsSync(d)) return false;
  const meta = readMeta(k, v); let dirty = false;
  for (const f of fs.readdirSync(d).filter(x => okFile(k, x))) {
    const base = f.replace(/\.disabled$/, ''), old = meta[base];
    if (old && (old.icon || old.tried)) continue;
    const file = path.join(d, f); let m = { title: (old && old.title) || '', icon: '' }, net = true;
    if (k === 'mods') {
      try {
        const j = JSON.parse(zipRead(file, 'fabric.mod.json').toString('utf8').replace(/^﻿/, ''));
        if (!m.title && j.name) m.title = String(j.name);
        let ic = j.icon; if (ic && typeof ic === 'object') ic = ic[Object.keys(ic).sort((x, y) => y - x)[0]];
        const img = typeof ic === 'string' && zipRead(file, ic.replace(/^\//, ''));
        if (img && img.length < 300000) m.icon = 'data:image/png;base64,' + img.toString('base64');
      } catch {}
    }
    if (!m.icon) {
      try {
        const r = await fetch(`${MR}/version_file/${sha1(fs.readFileSync(file))}?algorithm=sha1`, { headers: UA });
        if (r.ok) { const pm = await projectMeta((await r.json()).project_id); m = { title: pm.title || m.title, icon: pm.icon }; }
      } catch { net = false; }
    }
    meta[base] = { ...m, tried: net }; dirty = true;
  }
  if (dirty) writeMeta(k, v, meta);
  return dirty;
}
ipcMain.handle('items:enrich', async (_, k, v) => { try { return { changed: await enrich(k, v), list: listItems(k, v) }; } catch { return { changed: false, list: listItems(k, v) }; } });
ipcMain.handle('items:search', async (_, k, q, v) => {
  try {
    const facets = { mods: [['project_type:mod'], ['categories:fabric']], shaders: [['project_type:shader'], ['categories:iris']], packs: [['project_type:resourcepack']] }[k];
    facets.push(['versions:' + v]);
    const r = await (await fetch(`${MR}/search?` + new URLSearchParams({ query: q || '', limit: '20', facets: JSON.stringify(facets), index: q ? 'relevance' : 'downloads' }), { headers: UA })).json();
    return { hits: (r.hits || []).map(h => ({ id: h.project_id, title: h.title, desc: h.description, icon: h.icon_url || '', downloads: h.downloads })) };
  } catch (e) { return { hits: [], error: 'Could not reach Modrinth. Check your internet.' }; }
});
async function installItem(k, id, v) {
  const seen = new Set(), got = [], isMod = k === 'mods';
  async function inst(pid, top) {
    if (seen.has(pid)) return; seen.add(pid);
    const q = { game_versions: JSON.stringify([v]) };
    if (LOADERS[k].length) q.loaders = JSON.stringify(LOADERS[k]);
    const vs = await (await fetch(`${MR}/project/${encodeURIComponent(pid)}/version?` + new URLSearchParams(q), { headers: UA })).json();
    if (!Array.isArray(vs) || !vs.length) { if (top) throw new Error(`No ${LABELS[k]} version for Minecraft ${v}${isMod ? ' with Fabric' : ''}.`); return; }
    if (isMod) for (const dep of vs[0].dependencies || []) if (dep.dependency_type === 'required' && dep.project_id) { try { await inst(dep.project_id, false); } catch {} }
    const f = vs[0].files.find(x => x.primary) || vs[0].files[0];
    if (!f || !okFile(k, path.basename(f.filename))) return;
    const fn = path.basename(f.filename), dest = path.join(itemsDir(k, v), fn);
    if (!fs.existsSync(dest)) {
      const buf = Buffer.from(await (await fetch(f.url)).arrayBuffer());
      if (f.hashes && f.hashes.sha1 && sha1(buf) !== f.hashes.sha1) throw new Error('Download was corrupted. Try again.');
      fs.mkdirSync(path.dirname(dest), { recursive: true }); fs.writeFileSync(dest, buf); got.push(fn);
    }
    const meta = readMeta(k, v);
    if (!meta[fn] || !meta[fn].icon) { try { meta[fn] = { ...(await projectMeta(pid)), tried: true }; writeMeta(k, v, meta); } catch {} }
  }
  await inst(id, true);
  return { got, list: listItems(k, v) };
}
ipcMain.handle('items:install', async (_, k, id, v) => {
  try { return { ok: true, ...(await installItem(k, id, v)) }; }
  catch (e) { return { error: String(e.message || e) }; }
});

async function ensureFabric(mc, root) {
  const lst = await (await fetch(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}`)).json();
  if (!Array.isArray(lst) || !lst.length) throw new Error(`Fabric does not support Minecraft ${mc}. Pick another version or switch to Vanilla.`);
  const lv = (lst.find(x => x.loader && x.loader.stable) || lst[0]).loader.version;
  const prof = await (await fetch(`https://meta.fabricmc.net/v2/versions/loader/${encodeURIComponent(mc)}/${lv}/profile/json`)).json();
  const dir = path.join(root, 'versions', prof.id); fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, prof.id + '.json'), JSON.stringify(prof));
  return prof.id;
}
function syncMods(mc, root) {
  const dst = path.join(root, 'mods'); fs.mkdirSync(dst, { recursive: true });
  for (const f of fs.readdirSync(dst)) if (f.endsWith('.jar')) fs.rmSync(path.join(dst, f), { force: true });
  for (const m of listItems('mods', mc)) if (m.enabled) fs.copyFileSync(path.join(itemsDir('mods', mc), m.file), path.join(dst, m.file));
}
/* Resource packs: copy the enabled ones into the game, then tell the game which to load (options.txt) */
function syncPacks(mc, root) {
  const dst = path.join(root, 'resourcepacks'); fs.mkdirSync(dst, { recursive: true });
  for (const f of fs.readdirSync(dst)) if (f.endsWith('.zip')) fs.rmSync(path.join(dst, f), { force: true });
  const on = listItems('packs', mc).filter(p => p.enabled);
  for (const p of on) fs.copyFileSync(path.join(itemsDir('packs', mc), p.file), path.join(dst, p.file));
  const opt = path.join(root, 'options.txt');
  const lines = fs.existsSync(opt) ? fs.readFileSync(opt, 'utf8').split(/\r?\n/) : [];
  const val = 'resourcePacks:' + JSON.stringify(['vanilla', ...on.map(p => 'file/' + p.file)]);
  const i = lines.findIndex(l => l.startsWith('resourcePacks:'));
  if (i >= 0) lines[i] = val; else lines.push(val);
  fs.writeFileSync(opt, lines.join('\n').replace(/\n*$/, '\n'));
}
/* Shaders: copy the enabled ones and tell Iris which one to use (only the first enabled one is used) */
function syncShaders(mc, root) {
  const dst = path.join(root, 'shaderpacks'); fs.mkdirSync(dst, { recursive: true });
  for (const f of fs.readdirSync(dst)) if (f.endsWith('.zip')) fs.rmSync(path.join(dst, f), { force: true });
  const on = listItems('shaders', mc).filter(p => p.enabled);
  for (const p of on) fs.copyFileSync(path.join(itemsDir('shaders', mc), p.file), path.join(dst, p.file));
  const cfgDir = path.join(root, 'config'); fs.mkdirSync(cfgDir, { recursive: true });
  fs.writeFileSync(path.join(cfgDir, 'iris.properties'), on.length ? `enableShaders=true\nshaderPack=${on[0].file}\n` : 'enableShaders=false\n');
}
/* Shaders need Iris. Install it from Modrinth once if it is missing */
async function ensureIris(v) {
  const d = itemsDir('mods', v);
  if (fs.existsSync(d) && fs.readdirSync(d).some(f => /^iris/i.test(f) && okFile('mods', f) && !f.endsWith('.disabled'))) return;
  await installItem('mods', 'iris', v);
}

function offlineAuth(name) {
  const h = crypto.createHash('md5').update('OfflinePlayer:' + name).digest();
  h[6] = (h[6] & 0x0f) | 0x30; h[8] = (h[8] & 0x3f) | 0x80;
  const hex = h.toString('hex');
  const uuid = [hex.slice(0, 8), hex.slice(8, 12), hex.slice(12, 16), hex.slice(16, 20), hex.slice(20)].join('-');
  return { access_token: uuid, client_token: uuid, uuid, name, user_properties: '{}', meta: { type: 'mojang', demo: false } };
}

ipcMain.handle('play', async (_, version) => {
  if (running) return { error: 'Minecraft is already running.' };
  try {
    const s = load();
    let authorization;
    if (s.mode === 'offline') {
      if (!/^[A-Za-z0-9_]{3,16}$/.test(s.name || '')) return { error: 'Pick a valid name first (3 to 16 letters, numbers or _).' };
      authorization = offlineAuth(s.name);
    } else {
      if (!account) {
        const name = await signIn(true);
        if (!name) return { error: 'Sign in with the Microsoft account that owns Minecraft: Java Edition, or switch to Offline in Settings.' };
        send('account', name);
      }
      authorization = account.mclc();
    }
    const info = (await (await fetch(MANIFEST)).json()).versions.find(v => v.id === version);
    const launcher = new Client();
    launcher.on('progress', p => send('progress', { type: p.type, pct: p.total ? Math.round(p.task / p.total * 100) : 0 }));
    const tail = [], keep = l => { String(l).split(/\r?\n/).forEach(x => x.trim() && tail.push(x.trim())); while (tail.length > 40) tail.shift(); };
    launcher.on('debug', keep);
    launcher.on('data', d => { keep(d); send('state', 'running'); });
    launcher.on('close', code => {
      running = false; stopSkinServer(); send('state', 'closed:' + code);
      if (code !== 0) {
        const bad = tail.slice().reverse().find(l => /error|exception|unsupported|invalid|could not|unable/i.test(l)) || tail[tail.length - 1] || '';
        send('crash', bad.slice(0, 220));
      }
    });
    const opts = {
      authorization,
      root: path.join(app.getPath('userData'), 'minecraft'),
      version: { number: version, type: info && info.type === 'release' ? 'release' : 'snapshot' },
      memory: { max: `${s.ram}G`, min: '1G' }
    };
    const anyShader = listItems('shaders', version).some(x => x.enabled);
    if (anyShader) { try { await ensureIris(version); } catch (e) { send('warn', 'Shaders need Iris, which could not be installed: ' + String(e.message || e)); } }
    if (s.loader === 'fabric' || anyShader) {
      try { opts.version.custom = await ensureFabric(version, opts.root); syncMods(version, opts.root); }
      catch (e) { return { error: 'Fabric setup failed: ' + String(e.message || e) }; }
    }
    try { syncPacks(version, opts.root); syncShaders(version, opts.root); } catch (e) { send('warn', 'Could not load resource packs or shaders: ' + String(e.message || e)); }
    if (s.javaPath) opts.javaPath = s.javaPath;
    else if (info && info.url) {
      try { opts.javaPath = await ensureJava(info.url); }
      catch (e) { send('warn', 'Could not get Java from Mojang (' + String(e.message || e) + '). Trying the Java on this computer.'); }
    }
    if (s.mode === 'offline' && skinPng(s)) {
      try {
        const jar = await ensureInjector();
        stopSkinServer();
        const port = await startSkinServer();
        opts.customArgs = [`-javaagent:${jar}=http://127.0.0.1:${port}`, '-Dauthlibinjector.noShowServerName'];
      } catch (e) { stopSkinServer(); send('warn', 'Playing without your skin: ' + String(e.message || e)); }
    }
    running = true;
    const proc = await launcher.launch(opts);
    if (!proc) { running = false; stopSkinServer(); return { error: 'Launch failed. Check your Java path and version in Settings.' }; }
    return { ok: true };
  } catch (e) { running = false; stopSkinServer(); return { error: String(e.message || e) }; }
});

ipcMain.handle('app:quit', () => {
  if (running && dialog.showMessageBoxSync(win, { type: 'question', buttons: ['Close Cubeline', 'Cancel'], defaultId: 1, cancelId: 1, message: 'Minecraft is still running. Close Cubeline anyway?', detail: 'Your skin may disappear in the game if you do.' }) === 1) return false;
  app.quit(); return true;
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
