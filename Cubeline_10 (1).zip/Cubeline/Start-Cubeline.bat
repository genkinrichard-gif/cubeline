@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Install Node.js first: https://nodejs.org & pause & exit /b)
if not exist node_modules (echo First run: installing, please wait... & call npm install)
call npm start
